var myset = new Set("tom","jim","jack");
var tot = myset.size
console.log(tot)