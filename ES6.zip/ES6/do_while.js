var n=10

do{
    if(n==5)
    //break;                       //REMOVE COMMENT TO SEE CHANGE

    console.log(n)
    n--
}while(n>=0 )