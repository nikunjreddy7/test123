var myobj= new Object
myobj.a=5;
myobj.b=12;

//console.log(myobj)  -REMOVE COMMET TO SEE CHANGE
delete myobj.a
//console.log(myobj)
console.log("a" in myobj)  //checking is a is in myobj