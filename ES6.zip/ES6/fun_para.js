//function with parameter
function add(n1,n2)
{
    var sum =n1+n2
    console.log("the sum" +sum)
}

add(12,13)