import { company, getCompany} from `./company1.js`

console.log(myCompany.getCcompany())
console.log(getCompany())