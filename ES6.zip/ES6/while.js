var num=5

var factorial=1

while(num>=1)
{
    factorial=factorial *num
    num--
}

console.log("the factorial is :" + factorial)