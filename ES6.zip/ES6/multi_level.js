class Root
{
    test()
    {
        console.log("call from parent class")
    }
}

class child extends Root{ }

class leaf extends child{ }

var obj=new leaf()
obj.test();