class student {
    constructor(rno,fname,lname)
    {
        this.rno =rno
        this.fname =fname
        this.lname =lname
        console.log('inside constructor')
    }

    set rollno(newRollno)
    {
        console.log('inside setter')
        this.rno=newRollno
    }
}

let s1= new student(101,'sachin','tendulkar')
console.log(s1)
s1.rno=201
console.log(s1)