var roles={
    type:"admin",

    displayType: function()
    {
        console.log(this.type)
    }
}

var super_role= Object.create(roles)
super_role.displayType();

var guest_role=Object.create(roles)
guest_role.type="guest"
guest_role.displayType();