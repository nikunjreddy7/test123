var myMap= new Map();
myMap.set("bar","baz")
console.log(myMap.size)

myMap.clear()

console.log(myMap.size)