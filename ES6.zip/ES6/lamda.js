var foo=(x) => 10+x
console.log(foo(10))

var msg= x=> {
    console.log(x)
}

msg(10)