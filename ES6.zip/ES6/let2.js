let balance=5999;
console.log(typeof balance)

let balance = {message:"hello"}
console.log(typeof balance);