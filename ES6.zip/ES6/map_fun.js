function userDetails(key,value)
{
    console.log("m["+key+"]=" +value);
}

var myMap= new Map();
myMap.set("id","admin")
myMap.set("pass","admin123")
myMap.forEach(userDetails)