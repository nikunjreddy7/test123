var fruits = new Array("apple","mango","orange","kiwi")

var sorted=fruits.sort()

console.log(sorted)