var dt=Date()
var dt1= new Date("September 16, 2021 11:37:15")

console.log("current date",dt)
console.log("current date",dt1.getDate())
console.log("current date",dt1.getDay())
console.log("current date",dt1.getFullYear())
console.log("current date",dt1.getHours())
console.log("current date",dt1.getSeconds())