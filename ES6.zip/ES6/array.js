var alpha;
alpha=["1","2","3","4"]

console.log(alpha[0])
console.log(alpha[1])

var num=[1,2,3,4,5]
console.log(num[0])
console.log(num[1])
console.log(num[2])
console.log(num[3])
console.log(num[4])