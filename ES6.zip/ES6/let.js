let count=100;  // LET IS USED TO USE FUNCTION MANY

for(let count=1;count<=10;count++)
{
    console.log("count value inside loop is", count)
}
console.log("count value inside loop is", count)

if (count==100)
{
    let count=50
    console.log("count inside ig block",count)
}
console.log(count)