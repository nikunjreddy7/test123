var numbers =[1,6,12]
console.log(numbers)

var element=numbers.pop()
console.log(numbers)

var element=numbers.push(20)
console.log(numbers)

var element=numbers.push(34)
console.log(numbers)

lenght=numbers.push(30)
lenght=numbers.push(2)
lenght=numbers.push(8)
console.log(numbers)

