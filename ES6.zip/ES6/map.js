var roles =new Map([
    ['r1','User'],
    ['r2','Guest'],
    ['r3','Admin'],
]);

console.log(roles.get('r2'))