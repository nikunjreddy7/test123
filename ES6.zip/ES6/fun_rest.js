function fun1(...params)
{
    console.log(params.length)
}

fun1(5)
fun1()
fun1(5,6,7)
