var num1=10;
var num2=2
var res=0

res=num1+num2
console.log("sum"+res)

res=num1-num2
console.log("difference"+res)

res=num1*num2
console.log("product"+res)

res=num1/num2
console.log("Quotient"+res)

res=num1%num2
console.log("Remainder"+res)

num1++
console.log("val of num1 after increment"+num1)

num2--
console.log("val of num1 after decrement"+num2)