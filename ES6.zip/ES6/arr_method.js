
var alph=["a","b","c"]
var numeric=[1,2,3]

var alphnumeric= alph.concat(numeric)

console.log(alphnumeric)