class staticmembers{
    static disp()
    {
        console.log('static function called')
    }
}

staticmembers.disp()