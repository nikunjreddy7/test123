var det ={name:"tom",ID:"E1001"}
var copy=Object.assign({},det) //COPIES DATA FROM DET TO COPY

console.log(copy)

for(let val in copy)
{
    console.log(copy[val])
}