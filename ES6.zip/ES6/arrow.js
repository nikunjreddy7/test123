const add=(n1,n2) => n1+n2
console.log(add(10,20))

const isEven =(n1) => {
    if(n1%2==0)
    return true;
    else
    return false;
}

console.log(isEven(10))