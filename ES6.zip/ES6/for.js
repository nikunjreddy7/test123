var n=6
var factorial=1

for(let i=n; i>=1 ;i--)
{
    factorial *=i;
}

console.log(factorial)