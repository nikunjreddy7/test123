function retstr()
{
    return "jdjklad"
}

var val =retstr()
console.log(val)