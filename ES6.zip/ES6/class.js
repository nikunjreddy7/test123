class polygon{
    constructor(height,width)
    {
        this.h=height;
        this.w=width;
    }
    test()
    {
        console.log("the height of th polygon:",this.h)
        console.log("the width of th polygon:",this.w) 
    }
}

var obj =new polygon(10,20)
obj.test();